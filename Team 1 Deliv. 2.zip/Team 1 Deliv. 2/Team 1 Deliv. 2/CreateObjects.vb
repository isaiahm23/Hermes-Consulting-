﻿Public Class CreateObjects
    Dim tableName As String
    Dim DemandList As List(Of Demand)
    Dim MarketPriceList As List(Of MarketPrice)
    Dim TransportCostList As List(Of TransportCost)
    Dim HoldingCostList As List(Of HoldingCost)
    Dim PasswordList As List(Of User)


    Dim DB_HermesDatabase As New Database
    Dim DB_HermesConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\DB_Hermes.mdb"
    Dim DB_HermesSQL As String
    Dim DB_HermesDataset As New DataSet

    Public Sub MakeObjects()

        'IWM: First, we get the table in the dataset updated
        tableName = "Password"
        DB_HermesSQL = "Select * From Password"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMUser As New User
            IWMUser.UserName = DB_HermesDataset.Tables("Password").Rows(rowNumber)("UserName")
            IWMPas.UserPassword = DB_HermesDataset.Tables("Password").Rows(rowNumber)("Password")
        Next

        'IWM: First, we get the table in the dataset updated
        tableName = "DemandByLocation"
        DB_HermesSQL = "Select * From DemandByLocation"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMDemand As New Demand
            IWMDemand.name = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Name")
            IWMDemand.units = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("U/M")
            IWMDemand.Richmond = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Richmond")
            IWMDemand.Charlotte = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Charlotte")
            IWMDemand.Columbia = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Columbia")
            IWMDemand.Baltimore = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Baltimore")
            IWMDemand.WashingtonDC = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Washington DC")
            IWMDemand.Nashville = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Nashville")
            IWMDemand.Atlanta = DB_HermesDataset.Tables("DemandByLocation").Rows(rowNumber)("Atlanta")


        Next

        'IWM: First, we get the table in the dataset updated
        tableName = "HoldingCostPerCar"
        DB_HermesSQL = "Select * From HoldingCostPerCar"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMHoldingCost As New HoldingCost
            IWMHoldingCost.Brand = DB_HermesDataset.Tables("HoldingCostPerCar").Rows(rowNumber)("Car Brand")
            IWMHoldingCost.units = DB_HermesDataset.Tables("HoldingCostPerCar").Rows(rowNumber)("Unit of Measure")
            IWMHoldingCost.Cost = DB_HermesDataset.Tables("HoldingCostPerCar").Rows(rowNumber)("Cost")

        Next

        'IWM: First, we get the table in the dataset updated
        tableName = "Inventory"
        DB_HermesSQL = "Select * From Inventory"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMInventory As New Inventory
            IWMInventory.inventory = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Initial Inventory")
            IWMInventory.units = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Units of Measure")
            IWMInventory.Richmond = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Richmond")
            IWMInventory.Charlotte = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Charlotte")
            IWMInventory.Columbia = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Columbia")
            IWMInventory.Baltimore = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Baltimore")
            IWMInventory.WashingtonDC = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Washington DC")
            IWMInventory.Nashville = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Nashville")
            IWMInventory.Atlanta = DB_HermesDataset.Tables("Inventory").Rows(rowNumber)("Atlanta")

        Next

        'IWM: First, we get the table in the dataset updated
        tableName = "MarketPricePerCar"
        DB_HermesSQL = "Select * From MarketPricePerCar"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMMarketPrice As New MarketPrice
            IWMMarketPrice.brand = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Brnad")
            IWMMarketPrice.units = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Units of Measure")
            IWMMarketPrice.Richmond = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Richmond")
            IWMMarketPrice.Charlotte = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Charlotte")
            IWMMarketPrice.Columbia = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Columbia")
            IWMMarketPrice.Baltimore = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Baltimore")
            IWMMarketPrice.WashingtonDC = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Washington DC")
            IWMMarketPrice.Nashville = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Nashville")
            IWMMarketPrice.Atlanta = DB_HermesDataset.Tables("MarketPricePerCar").Rows(rowNumber)("Market Price in Atlanta")
        Next

        'IWM: First, we get the table in the dataset updated
        tableName = "TransportCostPerLocation"
        DB_HermesSQL = "Select * From TransportationCostPerLocation"
        DB_HermesDatabase.RunSQL(DB_HermesConnectionString, DB_HermesSQL, DB_HermesDataset, tableName)

        'IWM: Transfer data from table to objects

        For rowNumber As Integer = 0 To DB_HermesDataset.Tables(tableName).Rows.Count - 1
            Dim IWMTransportCost As New TransportCost
            IWMTransportCost.Shipping = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Initial Inventory")
            IWMTransportCost.units = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Units of Measure")
            IWMTransportCost.Richmond = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Richmond")
            IWMTransportCost.Charlotte = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Charlotte")
            IWMTransportCost.Columbia = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Columbia")
            IWMTransportCost.Baltimore = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Baltimore")
            IWMTransportCost.WashingtonDC = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Washington DC")
            IWMTransportCost.Nashville = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Nashville")
            IWMTransportCost.Atlanta = DB_HermesDataset.Tables("TransportCostPerLocation").Rows(rowNumber)("Atlanta")

        Next

    End Sub

    Public Sub Query()

    End Sub
End Class


