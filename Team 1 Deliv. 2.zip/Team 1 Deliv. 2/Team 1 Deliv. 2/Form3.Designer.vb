﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnFindSolution = New System.Windows.Forms.Button()
        Me.lblChooseOutput = New System.Windows.Forms.Label()
        Me.cbxChooseDesiredOutput = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnFindSolution
        '
        Me.btnFindSolution.Location = New System.Drawing.Point(241, 138)
        Me.btnFindSolution.Margin = New System.Windows.Forms.Padding(1)
        Me.btnFindSolution.Name = "btnFindSolution"
        Me.btnFindSolution.Size = New System.Drawing.Size(143, 39)
        Me.btnFindSolution.TabIndex = 5
        Me.btnFindSolution.Text = "Find Solution"
        Me.btnFindSolution.UseVisualStyleBackColor = True
        '
        'lblChooseOutput
        '
        Me.lblChooseOutput.AutoSize = True
        Me.lblChooseOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.900001!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChooseOutput.Location = New System.Drawing.Point(132, 85)
        Me.lblChooseOutput.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblChooseOutput.Name = "lblChooseOutput"
        Me.lblChooseOutput.Size = New System.Drawing.Size(171, 17)
        Me.lblChooseOutput.TabIndex = 4
        Me.lblChooseOutput.Text = "What are you looking for?"
        '
        'cbxChooseDesiredOutput
        '
        Me.cbxChooseDesiredOutput.FormattingEnabled = True
        Me.cbxChooseDesiredOutput.Items.AddRange(New Object() {"Total Transportation Cost", "Profit", "Total Inventory Holding Cost", "Optimal Cost"})
        Me.cbxChooseDesiredOutput.Location = New System.Drawing.Point(299, 84)
        Me.cbxChooseDesiredOutput.Margin = New System.Windows.Forms.Padding(1)
        Me.cbxChooseDesiredOutput.Name = "cbxChooseDesiredOutput"
        Me.cbxChooseDesiredOutput.Size = New System.Drawing.Size(234, 21)
        Me.cbxChooseDesiredOutput.TabIndex = 3
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 261)
        Me.Controls.Add(Me.btnFindSolution)
        Me.Controls.Add(Me.lblChooseOutput)
        Me.Controls.Add(Me.cbxChooseDesiredOutput)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnFindSolution As Button
    Friend WithEvents lblChooseOutput As Label
    Friend WithEvents cbxChooseDesiredOutput As ComboBox
End Class
