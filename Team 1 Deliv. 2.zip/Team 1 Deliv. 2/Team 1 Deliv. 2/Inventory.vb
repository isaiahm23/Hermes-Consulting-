﻿Public Class Inventory

    Public Property inventory As String
    Public Property units As String
    Public Property Richmond As Single
    Public Property Charlotte As Single
    Public Property Columbia As Single
    Public Property Baltimore As Single
    Public Property WashingtonDC As Single
    Public Property Nashville As Single
    Public Property Atlanta As Single

End Class
