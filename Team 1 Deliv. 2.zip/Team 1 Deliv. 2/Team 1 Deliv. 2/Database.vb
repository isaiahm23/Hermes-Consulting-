﻿Imports System.Data.OleDb
Public Class Database

    Private IWMDataAdapter As New OleDbDataAdapter
    Private IWMConnection As New OleDbConnection
    Private IWM_ICDB4Database As New Database
    Private IWM_ICDB4ConnectionString As String
    Private IWMCommand As New OleDbCommand
    Private IWM_ICDB4SQL As String
    Private IWM_ICDB4Dataset As New DataSet
    Private IWMTableName As String
    Public Sub New()

    End Sub
    Public Sub RunSQL(IWMConnectionString, IWM_ICDB4SQL, IWM_ICDB4Dataset, IWMTableName)
        'IWM: We set up a Connection Object
        IWMConnectionString.ConnectionString = IWM_ICDB4ConnectionString


        'IWM: We set up the Command object
        IWMCommand = IWMConnection.CreateCommand()
        IWMCommand.CommandText = IWM_ICDB4SQL

        'IWM: We set yp the DataAdapter object
        IWMDataAdapter.SelectCommand = IWMCommand
        IWMDataAdapter.Fill(IWM_ICDB4Dataset, IWMTableName)

    End Sub

End Class
