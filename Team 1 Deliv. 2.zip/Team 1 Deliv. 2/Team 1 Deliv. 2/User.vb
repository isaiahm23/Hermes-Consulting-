﻿Public Class User

    Public Property UserName As String
    Public Property UserPassword As String

End Class
