﻿Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'DNI: Login button takes user to SDI form
        'IWM: Checks User Name and Password to allow the user to enter the forms
        If txtUserName.Text = User.Equals("UserName") Then
            Form2.Show()
        Else
            MessageBox.Show("Incorrect User Name")
        End If

        If txtUserName.Text = User.Equals("Password") Then
            Form2.Show()
        Else
            MessageBox.Show("Incorrect Password")

        End If
    End Sub

End Class
