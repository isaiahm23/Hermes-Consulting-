﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.lblTreyEmail = New System.Windows.Forms.Label()
        Me.lblIsaiahEmail = New System.Windows.Forms.Label()
        Me.lblDanielleEmail = New System.Windows.Forms.Label()
        Me.lblChrisEmail = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.lblChristopher = New System.Windows.Forms.Label()
        Me.lblIsaiah = New System.Windows.Forms.Label()
        Me.lblDanielle = New System.Windows.Forms.Label()
        Me.lblTrey = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTreyEmail
        '
        Me.lblTreyEmail.AutoSize = True
        Me.lblTreyEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTreyEmail.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblTreyEmail.Location = New System.Drawing.Point(658, 248)
        Me.lblTreyEmail.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblTreyEmail.Name = "lblTreyEmail"
        Me.lblTreyEmail.Size = New System.Drawing.Size(103, 20)
        Me.lblTreyEmail.TabIndex = 24
        Me.lblTreyEmail.Text = "trey2@vt.edu"
        '
        'lblIsaiahEmail
        '
        Me.lblIsaiahEmail.AutoSize = True
        Me.lblIsaiahEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIsaiahEmail.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblIsaiahEmail.Location = New System.Drawing.Point(438, 248)
        Me.lblIsaiahEmail.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblIsaiahEmail.Name = "lblIsaiahEmail"
        Me.lblIsaiahEmail.Size = New System.Drawing.Size(122, 20)
        Me.lblIsaiahEmail.TabIndex = 23
        Me.lblIsaiahEmail.Text = "isaiahm@vt.edu"
        '
        'lblDanielleEmail
        '
        Me.lblDanielleEmail.AutoSize = True
        Me.lblDanielleEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDanielleEmail.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblDanielleEmail.Location = New System.Drawing.Point(243, 248)
        Me.lblDanielleEmail.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblDanielleEmail.Name = "lblDanielleEmail"
        Me.lblDanielleEmail.Size = New System.Drawing.Size(116, 20)
        Me.lblDanielleEmail.TabIndex = 22
        Me.lblDanielleEmail.Text = "dani17@vt.edu"
        '
        'lblChrisEmail
        '
        Me.lblChrisEmail.AutoSize = True
        Me.lblChrisEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChrisEmail.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblChrisEmail.Location = New System.Drawing.Point(16, 250)
        Me.lblChrisEmail.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblChrisEmail.Name = "lblChrisEmail"
        Me.lblChrisEmail.Size = New System.Drawing.Size(165, 20)
        Me.lblChrisEmail.TabIndex = 21
        Me.lblChrisEmail.Text = "cris10116@gmail.com"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(216, 10)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(1)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(153, 168)
        Me.PictureBox2.TabIndex = 20
        Me.PictureBox2.TabStop = False
        '
        'lblChristopher
        '
        Me.lblChristopher.AutoSize = True
        Me.lblChristopher.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChristopher.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblChristopher.Location = New System.Drawing.Point(-3, 206)
        Me.lblChristopher.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblChristopher.Name = "lblChristopher"
        Me.lblChristopher.Size = New System.Drawing.Size(208, 24)
        Me.lblChristopher.TabIndex = 19
        Me.lblChristopher.Text = "Christopher Perreault"
        '
        'lblIsaiah
        '
        Me.lblIsaiah.AutoSize = True
        Me.lblIsaiah.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIsaiah.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblIsaiah.Location = New System.Drawing.Point(417, 206)
        Me.lblIsaiah.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblIsaiah.Name = "lblIsaiah"
        Me.lblIsaiah.Size = New System.Drawing.Size(178, 24)
        Me.lblIsaiah.TabIndex = 18
        Me.lblIsaiah.Text = "Isaiah McLaughlin"
        '
        'lblDanielle
        '
        Me.lblDanielle.AutoSize = True
        Me.lblDanielle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDanielle.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblDanielle.Location = New System.Drawing.Point(238, 206)
        Me.lblDanielle.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblDanielle.Name = "lblDanielle"
        Me.lblDanielle.Size = New System.Drawing.Size(125, 24)
        Me.lblDanielle.TabIndex = 17
        Me.lblDanielle.Text = "Danielle Ilari"
        '
        'lblTrey
        '
        Me.lblTrey.AutoSize = True
        Me.lblTrey.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.1!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrey.ForeColor = System.Drawing.Color.MidnightBlue
        Me.lblTrey.Location = New System.Drawing.Point(651, 206)
        Me.lblTrey.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblTrey.Name = "lblTrey"
        Me.lblTrey.Size = New System.Drawing.Size(121, 24)
        Me.lblTrey.TabIndex = 16
        Me.lblTrey.Text = "Trey Collins"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(20, 10)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(1)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(153, 168)
        Me.PictureBox4.TabIndex = 15
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(412, 10)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(1)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(165, 170)
        Me.PictureBox3.TabIndex = 14
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(623, 10)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(159, 168)
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 414)
        Me.Controls.Add(Me.lblTreyEmail)
        Me.Controls.Add(Me.lblIsaiahEmail)
        Me.Controls.Add(Me.lblDanielleEmail)
        Me.Controls.Add(Me.lblChrisEmail)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lblChristopher)
        Me.Controls.Add(Me.lblIsaiah)
        Me.Controls.Add(Me.lblDanielle)
        Me.Controls.Add(Me.lblTrey)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form5"
        Me.Text = "Form5"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTreyEmail As Label
    Friend WithEvents lblIsaiahEmail As Label
    Friend WithEvents lblDanielleEmail As Label
    Friend WithEvents lblChrisEmail As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents lblChristopher As Label
    Friend WithEvents lblIsaiah As Label
    Friend WithEvents lblDanielle As Label
    Friend WithEvents lblTrey As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
