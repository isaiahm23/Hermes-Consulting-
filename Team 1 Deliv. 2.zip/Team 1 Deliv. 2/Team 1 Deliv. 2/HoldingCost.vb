﻿Public Class HoldingCost

    Public Property brand As String
    Public Property units As String
    Public Property cost As Double

End Class
